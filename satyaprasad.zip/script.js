
document.addEventListener("DOMContentLoaded", () => {

/* =====================================================
   02. FOOTER CURRENT YEAR
   =====================================================

   Automatically changes the footer year.

   HTML:
   <span id="yr"></span>

   Example:
   © 2026 Satya Prasad
   ===================================================== */

const yearElement = document.getElementById("yr");

if (yearElement) {

    yearElement.textContent = new Date().getFullYear();

}



/* =====================================================
   03. HERO AI DOCUMENT ANIMATION
   =====================================================

   The hero contains:

   - Highlighted words inside <mark>
   - Extracted information inside .row

   The animation gradually activates both.

   ===================================================== */

const highlights = document.querySelectorAll(".doc mark");

const outputRows = document.querySelectorAll(".out .row");


/*
   Animation function

   This function removes all existing
   animation classes and starts again.
*/

function playHeroAnimation() {


    /* ---------------------------------------------
       Remove existing animation states
       --------------------------------------------- */

    highlights.forEach((item) => {

        item.classList.remove("on");

    });


    outputRows.forEach((item) => {

        item.classList.remove("on");

    });


    /* ---------------------------------------------
       Animate highlighted text
       --------------------------------------------- */

    highlights.forEach((item, index) => {

        setTimeout(() => {

            item.classList.add("on");

        }, 500 + (index * 450));

    });


    /* ---------------------------------------------
       Animate extracted rows
       --------------------------------------------- */

    outputRows.forEach((item, index) => {

        setTimeout(() => {

            item.classList.add("on");

        }, 1500 + (index * 450));

    });

}



/* =====================================================
   04. RUN HERO ANIMATION
   ===================================================== */

/*
   Small delay makes the animation feel intentional
   instead of starting immediately when the page loads.
*/

setTimeout(() => {

    playHeroAnimation();

}, 500);



/* =====================================================
   05. HERO REPLAY BUTTON
   ===================================================== */

const replayButton = document.getElementById("rp");


if (replayButton) {

    replayButton.addEventListener("click", () => {

        playHeroAnimation();

    });

}



/* =====================================================
   06. BENTO CARD MOUSE EFFECT
   =====================================================

   When the user moves their mouse over a card,
   the CSS radial gradient follows the cursor.

   CSS variables:

   --mx
   --my

   ===================================================== */

const bentoCards = document.querySelectorAll(".bx");


bentoCards.forEach((card) => {


    card.addEventListener("pointermove", (event) => {


        /*
           Get the card's position
        */

        const rect = card.getBoundingClientRect();


        /*
           Calculate mouse position
           relative to the card.
        */

        const x = event.clientX - rect.left;

        const y = event.clientY - rect.top;


        /*
           Send the values to CSS.
        */

        card.style.setProperty(
            "--mx",
            `${x}px`
        );


        card.style.setProperty(
            "--my",
            `${y}px`
        );

    });


});



/* =====================================================
   07. PERSONAL PHOTO SLIDER
   =====================================================

   HTML structure:

   .photos-slider
       .photos-track
           .photo-card
           .photo-card
           .photo-card
           ...

   The slider automatically calculates how many
   photos should be visible based on screen width.

   Desktop:
   3 photos

   Tablet:
   2 photos

   Mobile:
   1 photo

   ===================================================== */

const photoTrack = document.getElementById("photosTrack");

const photoPreviousButton =
    document.getElementById("photoPrev");

const photoNextButton =
    document.getElementById("photoNext");


/*
   Only initialise the slider if all required
   elements exist.
*/

if (
    photoTrack &&
    photoPreviousButton &&
    photoNextButton
) {


    const photoCards =
        Array.from(
            photoTrack.querySelectorAll(".photo-card")
        );


    /*
       Current photo position.
    */

    let photoIndex = 0;


    /*
       Automatic slide timer.
    */

    let photoTimer = null;


    /*
       Determine how many cards are visible.
    */

    function getVisiblePhotos() {


        const screenWidth =
            window.innerWidth;


        if (screenWidth <= 600) {

            return 1;

        }


        if (screenWidth <= 1000) {

            return 2;

        }


        return 3;

    }



    /*
       Calculate the maximum possible
       slider position.
    */

    function getMaximumPhotoIndex() {


        const visiblePhotos =
            getVisiblePhotos();


        return Math.max(
            0,
            photoCards.length - visiblePhotos
        );

    }



    /*
       Move the photo track.
    */

    function updatePhotoSlider() {


        if (!photoCards.length) {

            return;

        }


        const firstCard =
            photoCards[0];


        const cardWidth =
            firstCard.getBoundingClientRect().width;


        /*
           CSS gap is 18px.
        */

        const gap = 18;


        const movement =
            photoIndex *
            (cardWidth + gap);


        photoTrack.style.transform =
            `translateX(-${movement}px)`;

    }



    /*
       Move to next photo.
    */

    function nextPhoto() {


        const maximumIndex =
            getMaximumPhotoIndex();


        /*
           When we reach the end,
           return to the first photo.
        */

        if (photoIndex >= maximumIndex) {

            photoIndex = 0;

        } else {

            photoIndex++;

        }


        updatePhotoSlider();

    }



    /*
       Move to previous photo.
    */

    function previousPhoto() {


        const maximumIndex =
            getMaximumPhotoIndex();


        /*
           If already at the beginning,
           jump to the final position.
        */

        if (photoIndex <= 0) {

            photoIndex = maximumIndex;

        } else {

            photoIndex--;

        }


        updatePhotoSlider();

    }



    /*
       Start automatic photo movement.
    */

    function startPhotoAutoSlide() {


        stopPhotoAutoSlide();


        photoTimer =
            setInterval(
                nextPhoto,
                4500
            );

    }



    /*
       Stop automatic photo movement.
    */

    function stopPhotoAutoSlide() {


        if (photoTimer) {

            clearInterval(photoTimer);

            photoTimer = null;

        }

    }



    /*
       Next button.
    */

    photoNextButton.addEventListener(
        "click",
        () => {

            nextPhoto();

            /*
               Restart timer so the slider does not
               immediately move again after clicking.
            */

            startPhotoAutoSlide();

        }
    );



    /*
       Previous button.
    */

    photoPreviousButton.addEventListener(
        "click",
        () => {

            previousPhoto();

            startPhotoAutoSlide();

        }
    );



    /*
       Pause automatic movement while
       the mouse is over the slider.
    */

    photoTrack.addEventListener(
        "mouseenter",
        stopPhotoAutoSlide
    );


    /*
       Resume movement when mouse leaves.
    */

    photoTrack.addEventListener(
        "mouseleave",
        startPhotoAutoSlide
    );



    /*
       Touch devices:

       Pause while the user interacts.
    */

    photoTrack.addEventListener(
        "touchstart",
        stopPhotoAutoSlide,
        {
            passive: true
        }
    );


    photoTrack.addEventListener(
        "touchend",
        startPhotoAutoSlide,
        {
            passive: true
        }
    );



    /*
       Recalculate slider position whenever
       browser width changes.
    */

    window.addEventListener(
        "resize",
        () => {


            const maximumIndex =
                getMaximumPhotoIndex();


            /*
               Prevent the index from becoming
               invalid after resizing.
            */

            if (photoIndex > maximumIndex) {

                photoIndex = maximumIndex;

            }


            updatePhotoSlider();

        }
    );



    /*
       Initial positioning.
    */

    updatePhotoSlider();


    /*
       Start automatic slider.
    */

    startPhotoAutoSlide();

}



/* =====================================================
   08. BOOK SLIDER
   =====================================================

   The book slider works similarly to the photo slider.

   Desktop:
   3 books

   Tablet:
   2 books

   Mobile:
   1 book

   It also creates navigation dots automatically.

   ===================================================== */

const bookTrack =
    document.getElementById("booksTrack");


const bookPreviousButton =
    document.getElementById("bookPrev");


const bookNextButton =
    document.getElementById("bookNext");


const bookDotsContainer =
    document.getElementById("bookDots");


/*
   Initialise only if all book slider
   elements exist.
*/

if (
    bookTrack &&
    bookPreviousButton &&
    bookNextButton &&
    bookDotsContainer)
{


    const bookCards =
        Array.from(
            bookTrack.querySelectorAll(".book-card")
        );
    

    /*
       Current book position.
    */

    let bookIndex = 0;


    /*
       Automatic slider timer.
    */

    let bookTimer = null;



    /* =================================================
       09. DETERMINE VISIBLE BOOKS
       ================================================= */

    function getVisibleBooks() {


        const screenWidth =
            window.innerWidth;


        if (screenWidth <= 600) {

            return 1;

        }


        if (screenWidth <= 1000) {

            return 2;

        }


        return 3;

    }



    /* =================================================
       10. DETERMINE MAXIMUM BOOK POSITION
       ================================================= */

    function getMaximumBookIndex() {


        const visibleBooks =
            getVisibleBooks();


        return Math.max(
            0,
            bookCards.length - visibleBooks
        );

    }



    /* =================================================
       11. CREATE BOOK NAVIGATION DOTS
       ================================================= */

    function createBookDots() {


        /*
           Remove existing dots first.

           This is useful if the function is called
           again after a layout change.
        */

        bookDotsContainer.innerHTML = "";


        const maximumIndex =
            getMaximumBookIndex();


        /*
           Create one dot for each possible
           slider position.
        */

        for (
            let index = 0;
            index <= maximumIndex;
            index++
        ) {


            const dot =
                document.createElement("button");


            dot.type = "button";


            dot.className =
                "book-dot";


            /*
               Accessibility label.
            */

            dot.setAttribute(
                "aria-label",
                `Go to book position ${index + 1}`
            );


            /*
               Active dot.
            */

            if (index === bookIndex) {

                dot.classList.add("active");

            }


            /*
               Clicking a dot moves directly
               to that position.
            */

            dot.addEventListener(
                "click",
                () => {

                    bookIndex = index;

                    updateBookSlider();

                    startBookAutoSlide();

                }
            );


            bookDotsContainer.appendChild(dot);

        }

    }



    /* =================================================
       12. UPDATE BOOK DOTS
       ================================================= */

    function updateBookDots() {


        const dots =
            bookDotsContainer.querySelectorAll(
                ".book-dot"
            );


        dots.forEach(
            (dot, index) => {


                dot.classList.toggle(
                    "active",
                    index === bookIndex
                );

            }
        );

    }



    /* =================================================
       13. MOVE BOOK SLIDER
       ================================================= */

    function updateBookSlider() {


        if (!bookCards.length) {

            return;

        }


        const firstCard =
            bookCards[0];


        const cardWidth =
            firstCard.getBoundingClientRect().width;


        /*
           CSS book gap is 20px.
        */

        const gap = 20;


        const movement =
            bookIndex *
            (cardWidth + gap);


        bookTrack.style.transform =
            `translateX(-${movement}px)`;


        /*
           Update navigation dots.
        */

        updateBookDots();

    }



    /* =================================================
       14. NEXT BOOK
       ================================================= */

    function nextBook() {


        const maximumIndex =
            getMaximumBookIndex();


        if (bookIndex >= maximumIndex) {

            bookIndex = 0;

        } else {

            bookIndex++;

        }


        updateBookSlider();

    }



    /* =================================================
       15. PREVIOUS BOOK
       ================================================= */

    function previousBook() {


        const maximumIndex =
            getMaximumBookIndex();


        if (bookIndex <= 0) {

            bookIndex = maximumIndex;

        } else {

            bookIndex--;

        }


        updateBookSlider();

    }



    /* =================================================
       16. START BOOK AUTO SLIDE
       ================================================= */

    function startBookAutoSlide() {


        stopBookAutoSlide();


        /*
           Books change every 5 seconds.
        */

        bookTimer =
            setInterval(
                nextBook,
                5000
            );

    }



    /* =================================================
       17. STOP BOOK AUTO SLIDE
       ================================================= */

    function stopBookAutoSlide() {


        if (bookTimer) {

            clearInterval(bookTimer);

            bookTimer = null;

        }

    }



    /* =================================================
       18. BOOK NEXT BUTTON
       ================================================= */

    bookNextButton.addEventListener(
        "click",
        () => {

            nextBook();

            startBookAutoSlide();

        }
    );



    /* =================================================
       19. BOOK PREVIOUS BUTTON
       ================================================= */

    bookPreviousButton.addEventListener(
        "click",
        () => {

            previousBook();

            startBookAutoSlide();

        }
    );



    /* =================================================
       20. PAUSE BOOK SLIDER ON HOVER
       ================================================= */

    bookTrack.addEventListener(
        "mouseenter",
        stopBookAutoSlide
    );


    bookTrack.addEventListener(
        "mouseleave",
        startBookAutoSlide
    );



    /* =================================================
       21. TOUCH SUPPORT FOR BOOKS
       ================================================= */

    bookTrack.addEventListener(
        "touchstart",
        stopBookAutoSlide,
        {
            passive: true
        }
    );


    bookTrack.addEventListener(
        "touchend",
        startBookAutoSlide,
        {
            passive: true
        }
    );



    /* =================================================
       22. RESPONSIVE BOOK SLIDER
       ================================================= */

    let previousVisibleBooks =
        getVisibleBooks();


    window.addEventListener(
        "resize",
        () => {


            const currentVisibleBooks =
                getVisibleBooks();


            /*
               If the number of visible books changes,
               recreate the navigation dots.
            */

            if (
                currentVisibleBooks !==
                previousVisibleBooks
            ) {


                previousVisibleBooks =
                    currentVisibleBooks;


                const maximumIndex =
                    getMaximumBookIndex();


                /*
                   Prevent invalid position.
                */

                if (
                    bookIndex >
                    maximumIndex
                ) {

                    bookIndex =
                        maximumIndex;

                }


                createBookDots();

            }


            updateBookSlider();

        }
    );



    /* =================================================
       23. INITIAL BOOK SLIDER SETUP
       ================================================= */

    createBookDots();

    updateBookSlider();

    startBookAutoSlide();

}



/* =====================================================
   24. SMOOTH ANCHOR SCROLLING
   =====================================================

   Keeps navigation links working smoothly while
   accounting for the fixed navigation bar.

   ===================================================== */

const navigationLinks =
    document.querySelectorAll(
        'a[href^="#"]'
    );


navigationLinks.forEach(
    (link) => {


        link.addEventListener(
            "click",
            (event) => {


                const targetId =
                    link.getAttribute("href");


                /*
                   Ignore empty anchors.
                */

                if (
                    !targetId ||
                    targetId === "#"
                ) {

                    return;

                }


                const target =
                    document.querySelector(
                        targetId
                    );


                /*
                   If target doesn't exist,
                   allow normal browser behavior.
                */

                if (!target) {

                    return;

                }


                event.preventDefault();


                /*
                   Account for fixed navigation.
                */

                const navigation =
                    document.querySelector(
                        ".main-nav"
                    );


                const navigationHeight =
                    navigation
                        ? navigation.offsetHeight
                        : 0;


                const targetPosition =
                    target.getBoundingClientRect().top +
                    window.scrollY -
                    navigationHeight -
                    20;


                window.scrollTo({

                    top: targetPosition,

                    behavior: "smooth"

                });

            }
        );

    }
);



/* =====================================================
   25. IMAGE ERROR HANDLING
   =====================================================

   If an image is missing, this prevents a broken
   image icon from ruining the layout.

   Instead, the image gets a subtle fallback
   background.

   ===================================================== */

const portfolioImages =
    document.querySelectorAll(
        "img"
    );


portfolioImages.forEach(
    (image) => {


        image.addEventListener(
            "error",
            () => {


                /*
                   Hide the broken image.
                */

                image.style.display =
                    "none";


                /*
                   Add a fallback class
                   to its parent.
                */

                if (image.parentElement) {

                    image.parentElement.classList.add(
                        "image-missing"
                    );

                }

            }
        );

    }
);



/* =====================================================
   26. PAGE LOAD COMPLETE
   =====================================================

   Add a class to the body after the initial
   JavaScript setup is complete.

   This can be used later for page-load animations
   without changing the HTML.

   ===================================================== */

document.body.classList.add(
    "js-ready"
);

/* =========================================================
   LIVE VIEWERS FLOATING CARD
   =========================================================

   The card moves slightly according to the
   user's scroll direction.

   Scrolling DOWN:
   Card moves slightly DOWN.

   Scrolling UP:
   Card moves slightly UP.

   This creates a subtle floating effect instead
   of keeping the card completely static.
   ========================================================= */

const liveViewersCard =
    document.getElementById("liveViewersCard");


if (liveViewersCard) {

    /* ---------------------------------------------
       Store previous scroll position
       --------------------------------------------- */

    let previousScrollY = window.scrollY;


    /* ---------------------------------------------
       Current floating offset
       --------------------------------------------- */

    let viewerCardOffset = 0;


    /* ---------------------------------------------
       Control how much the card moves
       --------------------------------------------- */

    const maximumOffset = 70;


    /* ---------------------------------------------
       Listen for page scrolling
       --------------------------------------------- */

    window.addEventListener(
        "scroll",
        () => {

            /*
               Current scroll position
            */

            const currentScrollY =
                window.scrollY;


            /*
               Determine scroll direction.

               Positive =
               user is scrolling down.

               Negative =
               user is scrolling up.
            */

            const scrollDifference =
                currentScrollY -
                previousScrollY;


            /*
               Ignore extremely small movements.
            */

            if (
                Math.abs(scrollDifference) > 1
            ) {

                /*
                   Move card according to
                   scroll direction.
                */

                viewerCardOffset +=
                    scrollDifference * 0.12;


                /*
                   Keep movement within
                   a controlled range.
                */

                viewerCardOffset =
                    Math.max(
                        -maximumOffset,
                        Math.min(
                            maximumOffset,
                            viewerCardOffset
                        )
                    );


                /*
                   Apply movement.

                   -50% keeps the card vertically
                   centered.

                   viewerCardOffset adds the
                   floating movement.
                */

                liveViewersCard.style.transform =
                    `translateY(
                        calc(-50% + ${viewerCardOffset}px)
                    )`;

            }


            /*
               Store current position
               for the next scroll event.
            */

            previousScrollY =
                currentScrollY;

        },

        {
            passive: true
        }

    );



    /* =====================================================
       RESET CARD POSITION AFTER USER STOPS SCROLLING
       ===================================================== */

    let scrollStopTimer;


    window.addEventListener(
        "scroll",
        () => {

            clearTimeout(scrollStopTimer);


            scrollStopTimer =
                setTimeout(
                    () => {

                        /*
                           Slowly return the card
                           to its natural center.
                        */

                        viewerCardOffset *= 0.35;


                        liveViewersCard.style.transform =
                            `translateY(
                                calc(-50% + ${viewerCardOffset}px)
                            )`;

                    },
                    180
                );

        },

        {
            passive: true
        }

    );



    /* =====================================================
       SIMULATED LIVE VIEWER COUNT
       =====================================================

       This changes the number slightly so the card
       feels alive.

       IMPORTANT:

       This is NOT a real visitor counter.

       For real visitors, replace this section with
       data from your backend / analytics system.
       ===================================================== */

    const viewerCountElement =
        document.getElementById(
            "liveViewersCount"
        );


    if (viewerCountElement) {

        /*
           Starting viewer count.
        */

        let viewerCount = 127;


        /*
           Change the number every 8 seconds.
        */

        setInterval(
            () => {

                /*
                   Random small change.

                   Possible values:

                   -2
                   -1
                    0
                   +1
                   +2
                */

                const change =
                    Math.floor(
                        Math.random() * 5
                    ) - 2;


                viewerCount += change;


                /*
                   Keep the number within
                   a reasonable range.
                */

                viewerCount =
                    Math.max(
                        80,
                        Math.min(
                            180,
                            viewerCount
                        )
                    );


                /*
                   Update the screen.
                */

                viewerCountElement.textContent =
                    viewerCount;

            },

            8000

        );

    }

}
});

